import React from "react";

type personProps = {
    name: string;
    myAge: number;
    isFemale: boolean;
}

type AnimalsListType = {
    animals: string[];
    animalType: 'bird' | 'fish' | 'mammal';
}

type someObjExamples = {
    obj: object;
    obj2: {};
    item: {
        id: string;
        name: string;
    };
    items: {
        id:string;
        name: string;
    }[];
}

type Item = {
    id: string;
    name: string;
}

type Items = {
    item: Item;
    items: Item[]
}

type CustomeItemHash = {
    [key: string]: Item;
}

type customeItemHash2 = {
    [key: number]: string
}

type Functions = {
    onHover: () => void;
    onChange: (id: number) => void;
    onClick: (e: React.MouseEvent<HTMLButtonElement>) => void;
}

const someFunction = (a: number, b: number) => {
    return a + b + "hello";
}

type OptionalProps = {
    required: string;
    optional?: string;
}

type OptionalProps2 = {
    required: string;
    optional?: string;
}

interface OptionalProps3 {
    required: string;
    optional?: string;
}

export {}