# Getting Started with Typescript and React

Project code-along for Coursera Guided Projects network by Rudi Hinds.

# Install all dependencies

Follow video instructions to the correct folder for the Task that you are on.

Run `npm install` in each of the project folders.

Follow along and enjoy!
